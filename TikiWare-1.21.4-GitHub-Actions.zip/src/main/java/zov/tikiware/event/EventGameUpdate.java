package zov.tikiware.event;

public class EventGameUpdate extends Event {}