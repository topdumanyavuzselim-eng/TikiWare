package zov.tikiware.event.list;

import lombok.AllArgsConstructor;
import lombok.Getter;
import net.minecraft.entity.Entity;
import zov.tikiware.event.Event;

@Getter
@AllArgsConstructor
public class EventEntitySpawn extends Event {
    private final Entity entity;
}