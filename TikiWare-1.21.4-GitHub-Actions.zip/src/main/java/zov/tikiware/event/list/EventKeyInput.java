package zov.tikiware.event.list;

import lombok.AllArgsConstructor;
import lombok.Getter;
import zov.tikiware.event.Event;

@Getter
@AllArgsConstructor
public class EventKeyInput extends Event {
    private final int key, action;
}