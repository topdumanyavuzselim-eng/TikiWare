package zov.tikiware.event.list;

import zov.tikiware.event.Event;

public class EventSprintSync extends Event {}