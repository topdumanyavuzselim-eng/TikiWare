package zov.tikiware.event.list;

import lombok.AllArgsConstructor;
import lombok.Getter;
import zov.tikiware.event.Event;

@Getter
@AllArgsConstructor
public class LookEvent extends Event {
    private double yaw, pitch;
}