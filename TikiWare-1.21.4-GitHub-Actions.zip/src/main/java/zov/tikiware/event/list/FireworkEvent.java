package zov.tikiware.event.list;

import net.minecraft.entity.LivingEntity;
import zov.tikiware.event.Event;

public class FireworkEvent extends Event {
    private final LivingEntity boostedEntity;
    private float speed;

    public FireworkEvent(LivingEntity boostedEntity, float speed) {
        this.boostedEntity = boostedEntity;
        this.speed = speed;
    }

    public LivingEntity getBoostedEntity() { return boostedEntity; }

    public float getSpeed() { return speed; }
    public void setSpeed(float speed) { this.speed = speed; }
}
