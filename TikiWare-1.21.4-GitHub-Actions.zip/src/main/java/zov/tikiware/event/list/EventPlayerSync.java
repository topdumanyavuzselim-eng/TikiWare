package zov.tikiware.event.list;

import zov.tikiware.event.Event;

public class EventPlayerSync extends Event {}