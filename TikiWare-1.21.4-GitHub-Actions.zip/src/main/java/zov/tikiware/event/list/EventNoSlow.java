package zov.tikiware.event.list;

import zov.tikiware.event.Event;

public class EventNoSlow extends Event {}