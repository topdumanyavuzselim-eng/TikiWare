package zov.tikiware.event.list;

import zov.tikiware.event.Event;

public class EventPlayerSyncEnd extends Event {}