package zov.tikiware.event.list;

import lombok.AllArgsConstructor;
import lombok.Getter;
import zov.tikiware.event.Event;

@Getter
@AllArgsConstructor
public class ChatEvent extends Event {
    private final String message;
}