package zov.tikiware.event;

import lombok.Data;
import zov.tikiware.TikiWare;

@Data
public class Event {
    private boolean cancelled;

    public void post() {
        TikiWare.getInstance().getEventBus().post(this);
    }

    public void cancelEvent() {
        setCancelled(true);
    }
}