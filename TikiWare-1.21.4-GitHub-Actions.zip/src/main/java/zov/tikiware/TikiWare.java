package zov.tikiware;

import com.google.common.eventbus.EventBus;
import com.google.common.eventbus.Subscribe;
import lombok.Getter;
import net.fabricmc.api.ModInitializer;
import net.minecraft.client.MinecraftClient;
import zov.tikiware.event.list.EventKeyInput;
import zov.tikiware.module.Module;
import zov.tikiware.module.ModuleStorage;
import zov.tikiware.util.commands.CommandDispatcher;
import zov.tikiware.util.commands.manager.CommandRepository;
import zov.tikiware.util.config.ConfigManager;
import zov.tikiware.util.draggable.DragManager;
import zov.tikiware.util.friend.FriendRepository;
import zov.tikiware.util.macro.MacroRepository;
import zov.tikiware.util.math.TPSGetter;
import zov.tikiware.util.player.combat.IdealHitUtils;
import zov.tikiware.util.player.other.ServerManager;
import zov.tikiware.util.rotation.ComponentManager;
import zov.tikiware.util.script.ScriptManager;
import zov.tikiware.util.staff.StaffManager;

import java.io.File;

public class TikiWare implements ModInitializer {

    private static TikiWare instance;

    @Getter
    private final EventBus eventBus;

    @Getter
    private final ModuleStorage moduleStorage;
    @Getter
    private final ComponentManager componentManager;
    @Getter
    private final DragManager dragManager;
    @Getter
    private final CommandRepository commandRepository;
    @Getter
    private final MacroRepository macroRepository;
    @Getter
    private final ConfigManager configManager;
    @Getter
    private final CommandDispatcher commandDispatcher;
    @Getter
    private final StaffManager staffManager;
    @Getter
    private final ServerManager serverManager;
    @Getter
    private final TPSGetter tpsGetter;
    @Getter
    private final IdealHitUtils idealHitUtils;
    @Getter
    private final ScriptManager scriptManager;

    public TikiWare() {
        instance = this;

        eventBus = new EventBus();
        eventBus.register(this);

        moduleStorage = new ModuleStorage();
        componentManager = new ComponentManager();
        dragManager = new DragManager();
        macroRepository = new MacroRepository();
        configManager = new ConfigManager();
        staffManager = new StaffManager();
        staffManager.load();
        commandRepository = new CommandRepository();
        commandDispatcher = new CommandDispatcher();
        serverManager = new ServerManager();
        tpsGetter = new TPSGetter();
        idealHitUtils = new IdealHitUtils();
        scriptManager = new ScriptManager();
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            ConfigManager.save("autocfg");
            getDragManager().saveDraggables();
            getMacroRepository().save();
            FriendRepository.save();
            staffManager.save();
        }));
        File dir = new File("tikiware/configs/");
        if (!dir.exists()) {
            dir.mkdirs();
        }
    }

    public static TikiWare getInstance() {
        return instance == null ? new TikiWare() : instance;
    }

    @Override
    public void onInitialize() {
        getModuleStorage().injectRegisterModules();
        componentManager.init();
        dragManager.load();
        macroRepository.load();
        FriendRepository.load();
        configManager.load("autocfg");
    }

    @Subscribe
    private void onModuleKeyPressed(EventKeyInput event) {
        for (Module module : getModuleStorage().getModules()) {
            if (event.getAction() == 1 && MinecraftClient.getInstance().currentScreen == null) {
                if (module.getKey() == event.getKey()) {
                    module.toggle();
                }
            }
        }
    }
}