package zov.tikiware.util.base;

public class ProtectException extends Exception {
    public ProtectException() {
        super();
    }
}