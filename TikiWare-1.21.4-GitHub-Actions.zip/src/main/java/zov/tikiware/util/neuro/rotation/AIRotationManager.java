package zov.tikiware.util.neuro.rotation;

import ai.djl.ModelException;
import ai.djl.translate.TranslateException;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import lombok.Getter;
import zov.tikiware.util.chat.ChatUtil;

import java.awt.*;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class AIRotationManager {
    
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path AI_DIR = Paths.get(".tikiWare", "ai");
    private static final Path DATASETS_DIR = AI_DIR.resolve("datasets");
    private static final Path MODELS_DIR = AI_DIR.resolve("models");
    
    @Getter
    private static AIRotationModel currentModel = null;
    
    static {
        try {
            Files.createDirectories(DATASETS_DIR);
            Files.createDirectories(MODELS_DIR);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void saveDataset(String name) {
        List<TrainingSample> samples = AIRotationRecorder.getSamples();
        if (samples.isEmpty()) {
            ChatUtil.send("§cNo data for saving! Use .ai start for started recording");
            return;
        }

        try {
            Path datasetPath = DATASETS_DIR.resolve(name + ".json");
            try (FileWriter writer = new FileWriter(datasetPath.toFile())) {
                GSON.toJson(samples, writer);
            }
            ChatUtil.send("§aDataset §e" + name + " §asaved (§f" + samples.size() + " §asamples)");
            ChatUtil.send("§7path: §f" + datasetPath.toAbsolutePath());
        } catch (IOException e) {
            ChatUtil.send("§cError saving dataset: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void trainModel(String datasetName, String modelName) {
        try {
            
            Path datasetPath = DATASETS_DIR.resolve(datasetName + ".json");
            if (!Files.exists(datasetPath)) {
                ChatUtil.send("§cDataset §e" + datasetName + " §cnot found!");
                return;
            }

            Type listType = new TypeToken<List<TrainingSample>>(){}.getType();
            List<TrainingSample> samples;
            
            try (FileReader reader = new FileReader(datasetPath.toFile())) {
                samples = GSON.fromJson(reader, listType);
            }

            if (samples == null || samples.isEmpty()) {
                ChatUtil.send("§cDataset empty!");
                return;
            }

            
            float[][] features = new float[samples.size()][];
            float[][] labels = new float[samples.size()][];
            
            for (int i = 0; i < samples.size(); i++) {
                features[i] = samples.get(i).getInput();
                labels[i] = samples.get(i).getOutput();
            }

            
            AIRotationModel model = new AIRotationModel(modelName);
            model.train(features, labels);

            
            Path modelPath = MODELS_DIR.resolve(modelName);
            model.save(modelPath);
            
            model.close();
            
            ChatUtil.send("§amodel §e" + modelName + " §asuccessfully trained and saved!");
            
        } catch (IOException | ModelException | TranslateException e) {
            ChatUtil.send("§cError training models: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void loadModel(String modelName) {
        try {
            Path modelPath = MODELS_DIR.resolve(modelName);
            if (!Files.exists(modelPath)) {
                ChatUtil.send("§cmodel §e" + modelName + " §cnot found!");
                System.out.println("MODEL PATH NOT FOUND: " + modelPath.toAbsolutePath());
                return;
            }

            if (currentModel != null) {
                currentModel.close();
            }

            System.out.println("Loading model from: " + modelPath.toAbsolutePath());
            currentModel = new AIRotationModel(modelName);
            currentModel.load(modelPath);
            
            ChatUtil.send("§amodel §e" + modelName + " §aactive!");
            System.out.println("MODEL LOADED SUCCESSFULLY: " + modelName);
            
        } catch (IOException | ModelException e) {
            ChatUtil.send("§cError loading models: " + e.getMessage());
            System.out.println("MODEL LOAD ERROR: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static float[] predict(float[] input) {
        if (currentModel == null) {
            System.out.println("AI MODEL IS NULL! Load a model first.");
            return new float[]{0, 0};
        }

        try {
            System.out.println("AI Input: [" + input[0] + ", " + input[1] + ", " + input[2] + ", " + input[3] + "]");
            float[] result = currentModel.predict(input);
            System.out.println("AI Output: [" + result[0] + ", " + result[1] + "]");
            return result;
        } catch (Exception e) {
            System.out.println("AI PREDICTION ERROR: " + e.getMessage());
            e.printStackTrace();
            return new float[]{0, 0};
        }
    }

    public static void listFiles() {
        ChatUtil.send("§e§l=== AI Rotation Files ===");
        
        
        File[] datasets = DATASETS_DIR.toFile().listFiles((dir, name) -> name.endsWith(".json"));
        if (datasets != null && datasets.length > 0) {
            ChatUtil.send("§aDatasets:");
            for (File dataset : datasets) {
                String name = dataset.getName().replace(".json", "");
                ChatUtil.send("  §7- §f" + name);
            }
        } else {
            ChatUtil.send("§7Datasets: §cno");
        }

        
        File[] models = MODELS_DIR.toFile().listFiles(File::isDirectory);
        if (models != null && models.length > 0) {
            ChatUtil.send("§amodels:");
            for (File model : models) {
                String name = model.getName();
                String status = currentModel != null && currentModel.toString().contains(name) ? " §a(active)" : "";
                ChatUtil.send("  §7- §f" + name + status);
            }
        } else {
            ChatUtil.send("§7models: §cno");
        }
    }

    public static void openDirectory() {
        try {
            Desktop.getDesktop().open(AI_DIR.toFile());
            ChatUtil.send("§afolder AI opened");
        } catch (IOException e) {
            ChatUtil.send("§cError opening folders: " + e.getMessage());
            ChatUtil.send("§7path: §f" + AI_DIR.toAbsolutePath());
        }
    }
}
