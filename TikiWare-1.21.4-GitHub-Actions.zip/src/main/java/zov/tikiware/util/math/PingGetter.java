package zov.tikiware.util.math;

import com.google.common.eventbus.Subscribe;
import lombok.Getter;
import net.minecraft.network.packet.s2c.common.CommonPingS2CPacket;
import zov.tikiware.TikiWare;
import zov.tikiware.event.list.EventPacket;
import zov.tikiware.event.list.EventTick;
import zov.tikiware.util.IMinecraft;

@Getter
public class PingGetter implements IMinecraft {
    public PingGetter() {
        TikiWare.getInstance().getEventBus().register(this);
    }

    private final StopWatch stopWatch = new StopWatch();
    private boolean lagged;
    private int ping;

    @Subscribe
    private void onUpdate(EventTick e) {
        ping = (int) stopWatch.getTime();
        if (stopWatch.getTime() > 1000) lagged = true;
    }

    @Subscribe
    private void onPacket(EventPacket e) {
        if (e.getPacket() instanceof CommonPingS2CPacket) {
            stopWatch.reset();
        }
    }
}