package zov.tikiware.util.rotation;

import zov.tikiware.util.IMinecraft;

public abstract class Component implements IMinecraft {
}