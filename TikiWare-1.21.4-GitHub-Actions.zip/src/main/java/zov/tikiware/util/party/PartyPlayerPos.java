package zov.tikiware.util.party;

public record PartyPlayerPos(
        String playerId,
        double x,
        double y,
        double z
) {}