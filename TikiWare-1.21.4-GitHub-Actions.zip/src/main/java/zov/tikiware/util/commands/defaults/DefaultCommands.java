

package zov.tikiware.util.commands.defaults;

import zov.tikiware.TikiWare;
import zov.tikiware.util.commands.api.ICommand;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public final class DefaultCommands {

    public static List<ICommand> createAll() {
        List<ICommand> commands = new ArrayList<>(Arrays.asList(
                new CfgCommand(),
                new RotationCommand(),
                new HelpCommand(TikiWare.getInstance()),
                new MacroCommand(TikiWare.getInstance()),
                new BindCommand(TikiWare.getInstance()),
                new FriendCommand(TikiWare.getInstance()),
                new StaffCommand(TikiWare.getInstance()),
                new VClipCommand(),
                new PartyCommand(),
                new GpsCommand(),
                new AICommand(),
                new BotCommand()
        ));
        return Collections.unmodifiableList(commands);
    }
}