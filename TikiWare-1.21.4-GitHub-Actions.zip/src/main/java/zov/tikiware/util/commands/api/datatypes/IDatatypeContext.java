package zov.tikiware.util.commands.api.datatypes;

import zov.tikiware.util.commands.api.argument.IArgConsumer;

public interface IDatatypeContext {
    IArgConsumer getConsumer();
}
