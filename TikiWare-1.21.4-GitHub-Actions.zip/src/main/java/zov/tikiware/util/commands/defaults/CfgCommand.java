package zov.tikiware.util.commands.defaults;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.HoverEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import zov.tikiware.util.commands.api.Command;
import zov.tikiware.util.commands.api.argument.IArgConsumer;
import zov.tikiware.util.commands.api.exception.CommandException;
import zov.tikiware.util.commands.api.exception.CommandNotEnoughArgumentsException;
import zov.tikiware.util.commands.api.helpers.Paginator;
import zov.tikiware.util.commands.api.helpers.TabCompleteHelper;
import zov.tikiware.util.config.ConfigManager;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

import static zov.tikiware.util.commands.api.IBaritoneChatControl.FORCE_COMMAND_PREFIX;

@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class CfgCommand extends Command {

    public CfgCommand() {
        super("cfg");
    }

    @Override
    public void execute(String label, IArgConsumer args) throws CommandException {
        String action = args.hasAny() ? args.getString().toLowerCase(Locale.US) : "list";

        switch (action) {
            case "save" -> handleSave(args);
            case "load" -> handleLoad(args);
            case "list" -> handleList(args, label);
            case "clear" -> {
                List<String> configs = ConfigManager.getConfigs();
                for (String name : configs) {
                    Path file = Paths.get("tikiware/configs").resolve(name + ".json");
                    if (Files.exists(file)) {
                        try {
                            Files.delete(file);
                        } catch (IOException e) {
                            logDirect(Formatting.GRAY + "Error when deletion file.");
                            e.printStackTrace();
                        }
                    }
                }
                logDirect("List configs cleared", Formatting.GRAY);
            }
            case "dir" -> {
                try {
                    File dir = new File("tikiware/configs/");
                    if (!dir.exists()) {
                        logDirect(Formatting.GRAY + "Enchant folder removed?");
                        dir.mkdirs();
                    } else {
                        logDirect(Formatting.GRAY + "Opening folder with configs...");
                    }
                    Runtime.getRuntime().exec("explorer " + dir.getAbsolutePath());
                } catch (IOException e) {
                    logDirect(Formatting.GRAY + "Error when opening folders: "
                            + Formatting.WHITE + e.getMessage());
                }
            }
            case "remove" -> handleRemove(args);
            default -> logDirect("Unknown subcommand. Use load/save/remove/list/dir.", Formatting.GRAY);
        }
    }

    private void handleSave(IArgConsumer args) throws CommandException {
        args.requireExactly(1);
        String name = args.getString();
        ConfigManager.save(name);
        logDirect(Formatting.GRAY + "Config with name " + Formatting.WHITE + name + Formatting.GRAY + " successfully saved");
    }

    private void handleLoad(IArgConsumer args) throws CommandException {
        args.requireExactly(1);
        String name = args.getString();

        if (!ConfigManager.getConfigs().contains(name)) {
            logDirect(Formatting.GRAY + "Config with such name not found");
            return;
        }

        ConfigManager.load(name);
        logDirect(Formatting.GRAY + "Config with name " + Formatting.WHITE + name + Formatting.GRAY + " successfully loaded");
    }

    private void handleList(IArgConsumer args, String label) throws CommandException {
        args.requireMax(1);
        List<String> configs = ConfigManager.getConfigs();

        logDirect("List configs:", Formatting.GRAY);
        Paginator.paginate(
                args,
                new Paginator<>(configs),
                name -> {
                    Text nameText = Text.literal(Formatting.GRAY + "- " + Formatting.WHITE + name + " ");
                    Text loadText = Text.literal(Formatting.GREEN + "[load]")
                            .styled(style -> style.withClickEvent(new ClickEvent(
                                    ClickEvent.Action.RUN_COMMAND,
                                    FORCE_COMMAND_PREFIX + "cfg load " + name
                            )).withHoverEvent(new HoverEvent(
                                    HoverEvent.Action.SHOW_TEXT,
                                    Text.literal("Click to load config")
                            )));
                    Text deleteText = Text.literal(Formatting.RED + " [Remove]")
                            .styled(style -> style.withClickEvent(new ClickEvent(
                                    ClickEvent.Action.RUN_COMMAND,
                                    FORCE_COMMAND_PREFIX + "cfg remove " + name
                            )).withHoverEvent(new HoverEvent(
                                    HoverEvent.Action.SHOW_TEXT,
                                    Text.literal("Click to delete config")
                            )));

                    return nameText.copy().append(loadText).append(deleteText);
                },
                FORCE_COMMAND_PREFIX + label
        );
    }

    private void handleRemove(IArgConsumer args) throws CommandException {
        args.requireExactly(1);
        String name = args.getString();

        Path file = Paths.get("tikiware/configs").resolve(name + ".json");
        if (Files.exists(file)) {
            try {
                Files.delete(file);
                logDirect(Formatting.GRAY + "Config " + Formatting.WHITE + name + Formatting.GRAY + " successfully removed");
            } catch (IOException e) {
                logDirect(Formatting.GRAY + "Error when deletion file.");
                e.printStackTrace();
            }
        } else {
            logDirect(Formatting.GRAY + "Config not found");
        }
    }

    @Override
    public Stream<String> tabComplete(String label, IArgConsumer args) throws CommandException {
        if (args.hasAny() && args.hasExactlyOne()) {
            return new TabCompleteHelper()
                    .sortAlphabetically()
                    .prepend("load", "save", "remove", "list", "clear", "dir")
                    .filterPrefix(args.getString())
                    .stream();
        } else if (args.hasAny()) {
            String arg = args.getString();
            if (args.hasExactlyOne() && (arg.equalsIgnoreCase("load") || arg.equalsIgnoreCase("remove"))) {
                return ConfigManager.getConfigs().stream()
                        .filter(cfg -> {
                            try {
                                return cfg.startsWith(args.peekString());
                            } catch (CommandNotEnoughArgumentsException e) {
                                throw new RuntimeException(e);
                            }
                        })
                        .sorted();
            }
        }

        return Stream.empty();
    }

    @Override
    public String getShortDesc() {
        return "Manage configs";
    }

    @Override
    public List<String> getLongDesc() {
        return Arrays.asList(
                "Command for management configs client.",
                "",
                "Usage:",
                "> cfg save <name> - Saves current config.",
                "> cfg load <name> - Loads config.",
                "> cfg list - Shows all available configs.",
                "> cfg remove <name> - Removes config by name."
        );
    }
}