package zov.tikiware.util.commands.defaults;

import zov.tikiware.TikiWare;
import zov.tikiware.util.chat.ChatUtil;
import zov.tikiware.util.commands.api.Command;
import zov.tikiware.util.commands.api.argument.IArgConsumer;
import zov.tikiware.util.commands.api.exception.CommandException;
import zov.tikiware.util.neuro.rotation.AIRotationManager;
import zov.tikiware.util.neuro.rotation.AIRotationRecorder;

import java.util.List;
import java.util.stream.Stream;

public class AICommand extends Command {
    
    private static AIRotationRecorder recorder = null;
    
    public AICommand() {
        super("ai");
    }

    @Override
    public void execute(String label, IArgConsumer args) throws CommandException {
        if (!args.hasAny()) {
            printHelp();
            return;
        }

        String subcommand = args.getString().toLowerCase();

        switch (subcommand) {
            case "start" -> {
                if (AIRotationRecorder.isRecording()) {
                    ChatUtil.send("§cRecording already going!");
                    return;
                }
                
                
                if (recorder == null) {
                    recorder = new AIRotationRecorder();
                    TikiWare.getInstance().getEventBus().register(recorder);
                }
                
                AIRotationRecorder.startRecording();
                ChatUtil.send("§aRecording started!");
                ChatUtil.send("§7Attack target, your movement will be recorded");
                ChatUtil.send("§7Use §f.ai stop §7for stopping");
            }

            case "stop" -> {
                if (!AIRotationRecorder.isRecording()) {
                    ChatUtil.send("§cRecording not going!");
                    return;
                }
                
                int samples = AIRotationRecorder.stopRecording();
                ChatUtil.send("§aRecording stopped!");
                ChatUtil.send("§7recorded samples: §f" + samples);
                ChatUtil.send("§7Use §f.ai save <name> §7for saving");
            }

            case "save" -> {
                if (!args.hasAny()) {
                    ChatUtil.send("§cUsage: §f.ai save <name>");
                    return;
                }
                String name = args.getString();
                AIRotationManager.saveDataset(name);
            }

            case "load" -> {
                if (!args.hasAny()) {
                    ChatUtil.send("§cUsage: §f.ai load <modelname>");
                    return;
                }
                String modelName = args.getString();
                AIRotationManager.loadModel(modelName);
            }

            case "train" -> {
                if (!args.has(2)) {
                    ChatUtil.send("§cUsage: §f.ai train <dataset> <modelname>");
                    return;
                }
                String datasetName = args.getString();
                String modelName = args.getString();
                
                ChatUtil.send("§7Starting training...");
                
                new Thread(() -> {
                    AIRotationManager.trainModel(datasetName, modelName);
                }).start();
            }

            case "list" -> {
                AIRotationManager.listFiles();
            }

            case "dir" -> {
                AIRotationManager.openDirectory();
            }

            default -> {
                ChatUtil.send("§cUnknown subcommand: §f" + subcommand);
                printHelp();
            }
        }
    }

    private void printHelp() {
        ChatUtil.send("§e§l=== AI Rotation Commands ===");
        ChatUtil.send("§f.ai start §7- start recording movements");
        ChatUtil.send("§f.ai stop §7- stop recording");
        ChatUtil.send("§f.ai save <name> §7- save dataset");
        ChatUtil.send("§f.ai train <dataset> <model> §7- train model");
        ChatUtil.send("§f.ai load <model> §7- load model");
        ChatUtil.send("§f.ai list §7- List files");
        ChatUtil.send("§f.ai dir §7- Open folder");
    }

    @Override
    public String getShortDesc() {
        return "Manage AI rotations";
    }

    @Override
    public List<String> getLongDesc() {
        return List.of(
                "Command for recording, training and use AI models rotations",
                "",
                "Usage:",
                ".ai start - start recording",
                ".ai stop - stop recording",
                ".ai save <name> - save dataset",
                ".ai train <dataset> <model> - train model",
                ".ai load <model> - load model",
                ".ai list - list files",
                ".ai dir - open folder"
        );
    }

    @Override
    public Stream<String> tabComplete(String label, IArgConsumer args) {
        if (args.hasExactlyOne()) {
            return Stream.of("start", "stop", "save", "load", "train", "list", "dir");
        }
        return Stream.empty();
    }
}
