

package zov.tikiware.util.commands;

import com.google.common.eventbus.Subscribe;
import net.minecraft.util.Pair;
import zov.tikiware.TikiWare;
import zov.tikiware.event.list.ChatEvent;
import zov.tikiware.event.list.TabCompleteEvent;
import zov.tikiware.util.commands.api.argument.ICommandArgument;
import zov.tikiware.util.commands.api.exception.CommandNotEnoughArgumentsException;
import zov.tikiware.util.commands.api.exception.CommandNotFoundException;
import zov.tikiware.util.commands.api.helpers.TabCompleteHelper;
import zov.tikiware.util.commands.api.manager.ICommandManager;
import zov.tikiware.util.commands.argument.ArgConsumer;
import zov.tikiware.util.commands.argument.CommandArguments;
import zov.tikiware.util.commands.manager.CommandRepository;

import java.util.List;
import java.util.stream.Stream;

import static zov.tikiware.util.commands.api.IBaritoneChatControl.FORCE_COMMAND_PREFIX;

public class CommandDispatcher {

    private final ICommandManager manager;

    public CommandDispatcher() {
        this.manager = TikiWare.getInstance().getCommandRepository();
        TikiWare.getInstance().getEventBus().register(this);
    }

    @Subscribe
    public void onSendChatMessage(ChatEvent event) {
        String msg = event.getMessage();
        String prefix = ".";
        boolean forceRun = msg.startsWith(FORCE_COMMAND_PREFIX);
        if ((msg.startsWith(prefix)) || forceRun) {
            event.setCancelled(true);
            String commandStr = msg.substring(forceRun ? FORCE_COMMAND_PREFIX.length() : prefix.length());
            if (!runCommand(commandStr) && !commandStr.trim().isEmpty()) {
                new CommandNotFoundException(CommandRepository.expand(commandStr).getLeft()).handle(null, null);
            }
        }
    }

    public boolean runCommand(String msg) {
        if (msg.isEmpty()) {
            return this.runCommand("help");
        }
        Pair<String, List<ICommandArgument>> pair = CommandRepository.expand(msg);
        return this.manager.execute(pair);
    }

    @Subscribe
    public void onPreTabComplete(TabCompleteEvent event) {
        String prefix = event.getPrefix();
        String commandPrefix = ".";
        if (!prefix.startsWith(commandPrefix)) {
            return;
        }
        String msg = prefix.substring(commandPrefix.length());
        List<ICommandArgument> args = CommandArguments.from(msg, true);
        Stream<String> stream = tabComplete(msg);
        if (args.size() == 1) {
            stream = stream.map(x -> commandPrefix + x);
        }
        event.completions = stream.toArray(String[]::new);
    }

    public Stream<String> tabComplete(String msg) {
        try {
            List<ICommandArgument> args = CommandArguments.from(msg, true);
            ArgConsumer argc = new ArgConsumer(this.manager, args);
            if (argc.hasAtMost(2)) {
                if (argc.hasExactly(1)) {
                    return new TabCompleteHelper()
                            .addCommands(this.manager)
                            .filterPrefix(argc.getString())
                            .stream();
                }
          
            }
            return this.manager.tabComplete(msg);
        } catch (CommandNotEnoughArgumentsException ignored) { 
            return Stream.empty();
        }
    }
}