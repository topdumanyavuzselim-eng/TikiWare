package zov.tikiware.util.commands.api.datatypes;

import zov.tikiware.util.IMinecraft;
import zov.tikiware.util.commands.api.exception.CommandException;

import java.util.stream.Stream;

public interface IDatatype extends IMinecraft {
    Stream<String> tabComplete(IDatatypeContext ctx) throws CommandException;
}
