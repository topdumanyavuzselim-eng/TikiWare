package zov.tikiware.util.commands.api.datatypes;

import zov.tikiware.util.commands.api.exception.CommandException;

public interface IDatatypeFor<T> extends IDatatype  {
    T get(IDatatypeContext datatypeContext) throws CommandException;
}
