package zov.tikiware.util.commands.defaults;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import zov.tikiware.TikiWare;
import zov.tikiware.util.commands.api.Command;
import zov.tikiware.util.commands.api.argument.IArgConsumer;
import zov.tikiware.util.commands.api.argument.ICommandArgument;
import zov.tikiware.util.commands.api.datatypes.KeyDataType;
import zov.tikiware.util.commands.api.exception.CommandException;
import zov.tikiware.util.commands.api.helpers.Paginator;
import zov.tikiware.util.commands.api.helpers.TabCompleteHelper;
import zov.tikiware.util.keyboard.KeyStorage;
import zov.tikiware.util.macro.MacroRepository;

import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

import static zov.tikiware.util.commands.api.IBaritoneChatControl.FORCE_COMMAND_PREFIX;

@FieldDefaults(level = AccessLevel.PRIVATE)
public class MacroCommand extends Command {

    final MacroRepository macroRepository;

    public MacroCommand(TikiWare tikiWare) {
        super("macro");
        macroRepository = tikiWare.getMacroRepository();
    }

    @Override
    public void execute(String label, IArgConsumer args) throws CommandException {
        String action = args.hasAny() ? args.getString().toLowerCase(Locale.US) : "list";
        switch (action) {
            case "add" -> handleAddMacro(args);
            case "remove" -> handleRemoveMacro(args);
            case "list" -> handleListMacros(args, label);
            case "clear" -> handleClearMacros(args);
            default -> logDirect("Use: add / remove / list / clear", Formatting.GRAY);
        }
    }

    private void handleAddMacro(IArgConsumer args) throws CommandException {
        args.requireMin(2);

        int key = args.getDatatypeFor(KeyDataType.INSTANCE).getValue();
        String command = args.rawRest();

        macroRepository.addMacro(command, key);

        logDirect(Formatting.GRAY +
                "Macro added: " + Formatting.WHITE +
                KeyStorage.getKey(key).toLowerCase() + Formatting.GRAY +
                " → " + Formatting.WHITE + command);
    }

    private void handleRemoveMacro(IArgConsumer args) throws CommandException {
        args.requireMin(1);

        int key = args.getDatatypeFor(KeyDataType.INSTANCE).getValue();

        if (macroRepository.removeByKey(key)) {
            logDirect(Formatting.GRAY + "Macro on key "
                    + Formatting.WHITE + KeyStorage.getKey(key).toLowerCase()
                    + Formatting.GRAY + " removed");
        } else {
            logDirect("Macro on this key not found", Formatting.GRAY);
        }
    }

    private void handleListMacros(IArgConsumer args, String label) throws CommandException {
        Paginator.paginate(
                args,
                new Paginator<>(macroRepository.getMacroList()),
                () -> logDirect("List macros:"),
                macro -> Text.literal(
                        Formatting.GRAY + " " +
                                KeyStorage.getKey(macro.key()).toLowerCase() +
                                Formatting.DARK_GRAY + " → " +
                                Formatting.WHITE + macro.message()
                ),
                FORCE_COMMAND_PREFIX + label
        );
    }

    private void handleClearMacros(IArgConsumer args) {
        macroRepository.clearList();
        logDirect("all macros cleared", Formatting.GRAY);
    }

    @Override
    public Stream<String> tabComplete(String label, IArgConsumer args) throws CommandException {
        List<ICommandArgument> raw = args.getArgs();
        int size = raw.size();

        if (args.hasExactlyOne()) {
            return new TabCompleteHelper()
                    .prepend("add", "remove", "list", "clear")
                    .filterPrefix(args.getString())
                    .sortAlphabetically()
                    .stream();
        }

        if (args.hasAny()) {
            String action = args.getString();
            if ((action.equalsIgnoreCase("add") || action.equalsIgnoreCase("remove")) && size == 2) {
                return args.tabCompleteDatatype(KeyDataType.INSTANCE);
            }
        }
        return Stream.empty();
    }

    @Override
    public String getShortDesc() {
        return "macros by keys";
    }

    @Override
    public List<String> getLongDesc() {
        return List.of(
                "Usage:",
                ".macro add <key> <command>",
                ".macro remove <key>",
                ".macro list",
                ".macro clear"
        );
    }
}