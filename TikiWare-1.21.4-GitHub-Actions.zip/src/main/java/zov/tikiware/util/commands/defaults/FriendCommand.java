package zov.tikiware.util.commands.defaults;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.HoverEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import zov.tikiware.TikiWare;
import zov.tikiware.util.commands.api.Command;
import zov.tikiware.util.commands.api.argument.IArgConsumer;
import zov.tikiware.util.commands.api.exception.CommandException;
import zov.tikiware.util.commands.api.helpers.Paginator;
import zov.tikiware.util.commands.api.helpers.TabCompleteHelper;
import zov.tikiware.util.friend.Friend;
import zov.tikiware.util.friend.FriendRepository;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

import static zov.tikiware.util.commands.api.IBaritoneChatControl.FORCE_COMMAND_PREFIX;

@FieldDefaults(level = AccessLevel.PRIVATE)
public class FriendCommand extends Command {

    public FriendCommand(TikiWare tikiWare) {
        super("friend");
    }

    @Override
    public void execute(String label, IArgConsumer args) throws CommandException {
        String action = args.hasAny() ? args.getString().toLowerCase(Locale.US) : "list";
        switch (action) {
            case "add" -> handleAddFriend(args);
            case "remove" -> handleRemoveFriend(args);
            case "list" -> handleListFriends(args, label);
            case "clear" -> handleClearFriends(args);
            default -> logDirect("Unknown subcommand. Use add/remove/list/clear.", Formatting.GRAY);
        }
    }

    private void handleAddFriend(IArgConsumer args) throws CommandException {
        args.requireMin(1);
        String name = args.getString();

        if (FriendRepository.isFriend(name)) {
            logDirect("this player already in list friends", Formatting.GRAY);
            return;
        }

        FriendRepository.addFriend(name);
        logDirect(Formatting.GRAY + "Player with name " + Formatting.WHITE + name + Formatting.GRAY + " successfully added in friends");
    }

    private void handleRemoveFriend(IArgConsumer args) throws CommandException {
        args.requireMin(1);
        String name = args.getString();

        if (!FriendRepository.isFriend(name)) {
            logDirect("Such friend not found", Formatting.GRAY);
            return;
        }

        FriendRepository.removeFriend(name);
        logDirect("Player with name " + Formatting.WHITE + name + Formatting.GRAY + " successfully removed from friends");
    }

    private void handleListFriends(IArgConsumer args, String label) throws CommandException {
        args.requireMax(1);
        List<Friend> friends = FriendRepository.getFriends();

        Paginator.paginate(
                args,
                new Paginator<>(friends),
                () -> logDirect("List friends:", Formatting.GRAY),
                friend -> {
                    Text nameText = Text.literal(Formatting.GRAY + "- " + Formatting.WHITE + friend.name());
                    Text deleteText = Text.literal(Formatting.RED + " [Remove]")
                            .styled(style -> style.withClickEvent(new ClickEvent(
                                    ClickEvent.Action.RUN_COMMAND,
                                    FORCE_COMMAND_PREFIX + "friend remove " + friend.name()
                            )).withHoverEvent(new HoverEvent(
                                    HoverEvent.Action.SHOW_TEXT,
                                    Text.literal("Click to delete friend")
                            )));

                    return nameText.copy().append(deleteText);
                },
                FORCE_COMMAND_PREFIX + label
        );
    }

    private void handleClearFriends(IArgConsumer args) throws CommandException {
        args.requireMax(1);
        FriendRepository.clear();
        logDirect("List friends cleared", Formatting.GRAY);
    }

    @Override
    public Stream<String> tabComplete(String label, IArgConsumer args) throws CommandException {
        if (args.hasAny() && args.hasExactlyOne()) {
            return new TabCompleteHelper()
                    .prepend("add", "remove", "list", "clear")
                    .filterPrefix(args.getString())
                    .sortAlphabetically()
                    .stream();
        } else if (args.hasAny()) {
            String action = args.peekString(0).toLowerCase(Locale.ROOT);
            if ((action.equals("remove")) && args.hasExactly(2)) {
                String prefix = args.peekString(1).toLowerCase(Locale.ROOT);
                return FriendRepository.getFriends().stream()
                        .map(Friend::name)
                        .filter(name -> name.toLowerCase(Locale.ROOT).startsWith(prefix))
                        .sorted()
                        .distinct();
            }
            if ((action.equals("add")) && args.hasExactly(2)) {
                String prefix = args.peekString(1).toLowerCase(Locale.ROOT);
                return MinecraftClient.getInstance().getNetworkHandler().getPlayerList().stream()
                        .map(info -> info.getProfile().getName())
                        .filter(name -> name.toLowerCase(Locale.ROOT).startsWith(prefix))
                        .sorted()
                        .distinct();
            }
        }
        return Stream.empty();
    }

    @Override
    public String getShortDesc() {
        return "Manage friends";
    }

    @Override
    public List<String> getLongDesc() {
        return Arrays.asList(
                "this command allows manage list friends.",
                "",
                "Usage:",
                "> friend add <name> - adds player in friends.",
                "> friend remove <name> - Removes player from friends.",
                "> friend list - Shows list all friends.",
                "> friend clear - Removes all friends."
        );
    }
}