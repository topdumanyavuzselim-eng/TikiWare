package zov.tikiware.util.commands.api.exception;

import zov.tikiware.util.QuickLogger;
import zov.tikiware.util.commands.api.ICommand;
import zov.tikiware.util.commands.api.argument.ICommandArgument;

import java.util.List;

public class CommandUnhandledException extends RuntimeException implements ICommandException, QuickLogger {

    public CommandUnhandledException(String message) {
        super(message);
    }

    public CommandUnhandledException(Throwable cause) {
        super(cause);
    }

    @Override
    public void handle(ICommand command, List<ICommandArgument> args) {
    }
}
