package zov.tikiware.util.commands;

import zov.tikiware.util.commands.api.ICommandSystem;
import zov.tikiware.util.commands.api.argparser.IArgParserManager;
import zov.tikiware.util.commands.argparser.ArgParserManager;

public enum CommandSystem implements ICommandSystem {
    INSTANCE;

    @Override
    public IArgParserManager getParserManager() {
        return ArgParserManager.INSTANCE;
    }
}
