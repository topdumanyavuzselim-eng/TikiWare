package zov.tikiware.util.commands.defaults;

import zov.tikiware.util.commands.api.Command;
import zov.tikiware.util.commands.api.argument.IArgConsumer;
import zov.tikiware.util.commands.api.exception.CommandException;
import zov.tikiware.util.commands.api.helpers.TabCompleteHelper;
import zov.tikiware.util.bot.BotSessionManager;

import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

public class BotCommand extends Command {

    public BotCommand() {
        super("bot");
    }

    @Override
    public void execute(String label, IArgConsumer args) throws CommandException {
        String action = args.hasAny() ? args.getString().toLowerCase(Locale.ROOT) : "list";

        switch (action) {
            case "connect" -> connect(args);
            case "remove" -> remove(args);
            case "return" -> restore();
            case "control" -> control(args);
            case "say" -> say(args);
            case "sayall" -> sayAll(args);
            case "list" -> list();
            default -> logDirect("Unknown subcommand. Use connect/remove/return/control/say/sayall/list");
        }
    }

    private void connect(IArgConsumer args) throws CommandException {
        args.requireMin(2);
        String name = args.getString();
        String ip = args.getString();
        BotSessionManager.connect(name, ip);
        logDirect("connection completed: " + name + " -> " + ip + " (Previous session frozen)");
    }

    private void remove(IArgConsumer args) throws CommandException {
        args.requireMin(1);
        String name = args.getString();
        if (BotSessionManager.remove(name)) {
            logDirect("Bot disconnected and removed: " + name);
            return;
        }
        logDirect("Bot not found: " + name);
    }

    private void control(IArgConsumer args) throws CommandException {
        args.requireMin(1);
        String name = args.getString();
        if (BotSessionManager.control(name)) {
            logDirect("switching on bot: " + name);
            return;
        }
        logDirect("Bot not found: " + name);
    }

    private void say(IArgConsumer args) throws CommandException {
        args.requireMin(2);
        String name = args.getString();
        StringBuilder message = new StringBuilder();
        while (args.hasAny()) {
            message.append(args.getString()).append(" ");
        }
        if (BotSessionManager.say(name, message.toString().trim())) {
            logDirect("message from face " + name + " sent.");
            return;
        }
        logDirect("Bot not found: " + name);
    }

    private void sayAll(IArgConsumer args) throws CommandException {
        args.requireMin(1);
        StringBuilder message = new StringBuilder();
        while (args.hasAny()) {
            message.append(args.getString()).append(" ");
        }
        BotSessionManager.sayAll(message.toString().trim());
        logDirect("message sent from all bots.");
    }

    private void restore() {
        if (BotSessionManager.restore()) {
            logDirect("Returning previous session");
            return;
        }
        logDirect("No saved session for return");
    }

    private void list() {
        List<BotSessionManager.BotConnection> connections = BotSessionManager.getConnections();
        if (connections.isEmpty()) {
            logDirect("List bots empty");
            return;
        }
        logDirect("Connected bots:");
        for (BotSessionManager.BotConnection connection : connections) {
            logDirect("- " + connection.name() + " @ " + connection.address());
        }
    }

    @Override
    public Stream<String> tabComplete(String label, IArgConsumer args) throws CommandException {
        if (args.hasExactlyOne()) {
            return new TabCompleteHelper()
                    .prepend("connect", "remove", "return", "control", "say", "sayall", "list")
                    .filterPrefix(args.getString())
                    .stream();
        }

        if (args.hasExactly(2)) {
            String action = args.peekString(0).toLowerCase(Locale.ROOT);
            if (List.of("remove", "control", "say").contains(action)) {
                String searchName = args.peekString(1).toLowerCase(Locale.ROOT);
                return BotSessionManager.getConnections().stream()
                        .map(BotSessionManager.BotConnection::name)
                        .filter(n -> n.toLowerCase().startsWith(searchName));
            }
            if (action.equals("connect")) return Stream.of("<name_bot>");
            if (action.equals("sayall")) return Stream.of("<message>");
        }

        if (args.hasExactly(3) && args.peekString(0).equalsIgnoreCase("connect")) {
            return Stream.of("<IP_server>");
        }

        return Stream.empty();
    }

    @Override
    public String getShortDesc() {
        return "Manage bot-sessions";
    }

    @Override
    public List<String> getLongDesc() {
        return List.of(
                "Manage bot-sessions and quick switching.",
                "",
                "Usage:",
                "> bot connect <name> <ip>",
                "> bot control <name>",
                "> bot say <name> <message>",
                "> bot sayall <message>",
                "> bot remove <name>",
                "> bot return",
                "> bot list"
        );
    }
}