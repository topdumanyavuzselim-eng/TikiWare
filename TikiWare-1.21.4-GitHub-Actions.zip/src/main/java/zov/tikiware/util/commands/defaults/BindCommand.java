package zov.tikiware.util.commands.defaults;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import zov.tikiware.TikiWare;
import zov.tikiware.module.Module;
import zov.tikiware.module.ModuleStorage;
import zov.tikiware.util.commands.api.Command;
import zov.tikiware.util.commands.api.argument.IArgConsumer;
import zov.tikiware.util.commands.api.argument.ICommandArgument;
import zov.tikiware.util.commands.api.datatypes.KeyDataType;
import zov.tikiware.util.commands.api.exception.CommandException;
import zov.tikiware.util.commands.api.helpers.Paginator;
import zov.tikiware.util.commands.api.helpers.TabCompleteHelper;
import zov.tikiware.util.keyboard.KeyStorage;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static zov.tikiware.util.commands.api.IBaritoneChatControl.FORCE_COMMAND_PREFIX;

@FieldDefaults(level = AccessLevel.PRIVATE)
public class BindCommand extends Command {

    final ModuleStorage moduleStorage;

    public BindCommand(TikiWare tikiWare) {
        super("bind");
        this.moduleStorage = tikiWare.getModuleStorage();
    }

    @Override
    public void execute(String label, IArgConsumer args) throws CommandException {
        String action = args.hasAny() ? args.getString().toLowerCase(Locale.US) : "list";
        switch (action) {
            case "add" ->
                handleAddBind(label, args);
            case "remove" ->
                handleRemoveBind(args);
            case "list" ->
                handleListBinds(args, label);
            case "clear" ->
                handleClearBinds(args);
            default -> logDirect("Unknown subcommand. Use add/remove/list/clear.", Formatting.GRAY);
        }
    }

    private void handleAddBind(String label, IArgConsumer args) throws CommandException {
        args.requireMin(2);
        String moduleName = args.getString();
        Module module = moduleStorage.get(moduleName);
        if (module == null) {
            logDirect(Formatting.GRAY + "Module with name " + Formatting.WHITE + moduleName + Formatting.GRAY + " not found");
            return;
        }
        int key = args.getDatatypeFor(KeyDataType.INSTANCE).getValue();
        module.setKey(key);
        logDirect(Formatting.GRAY + "Module " + Formatting.WHITE + module.getName() + Formatting.GRAY + " successfully bound to key " + Formatting.WHITE + KeyStorage.getKey(key).toUpperCase());
    }

    private void handleRemoveBind(IArgConsumer args) throws CommandException {
        args.requireMin(1);
        String moduleName = args.getString();
        Module module = moduleStorage.get(moduleName);
        if (module == null) {
            logDirect(Formatting.GRAY + "Module with name " + Formatting.WHITE + moduleName + Formatting.GRAY + " not found");
            return;
        }
        module.setKey(-1);
        logDirect(Formatting.GRAY + "Module " + Formatting.WHITE + module.getName() + Formatting.GRAY + " more not has binding to key");
    }

    private void handleListBinds(IArgConsumer args, String label) throws CommandException {
        args.requireMax(1);

        List<Module> boundModules = moduleStorage.getModules()
                .stream()
                .filter(module -> module.getKey() != -1)
                .collect(Collectors.toList());

        Paginator.paginate(
                args,
                new Paginator<>(boundModules),
                () -> logDirect("Bound modules:"),
                module -> {
                    int key = module.getKey();
                    String keyName = KeyStorage.getKey(key).toUpperCase();
                    return Text.literal(Formatting.GRAY + module.getName() + ": " + Formatting.WHITE + keyName);
                },
                FORCE_COMMAND_PREFIX + label
        );
    }

    private void handleClearBinds(IArgConsumer args) throws CommandException {
        args.requireMax(1);
        for (Module m : moduleStorage.getModules()) {
            m.setKey(-1);
        }
        logDirect(Formatting.GRAY + "all modules successfully unbound and more not have binding to key");
    }

    @Override
    public Stream<String> tabComplete(String label, IArgConsumer args) throws CommandException {
        List<ICommandArgument> raw = args.getArgs();
        int size = raw.size();

        if (size <= 1) {
            String prefix = size == 1 ? args.peekString(0) : "";
            return new TabCompleteHelper()
                    .prepend("add", "remove", "list", "clear")
                    .filterPrefix(prefix)
                    .sortAlphabetically()
                    .stream();
        }

        String action = args.peekString(0).toLowerCase(Locale.ROOT);

        if ((action.equals("add")) && size == 2) {
            String modulePrefix = args.peekString(1);
            return moduleStorage.getModules().stream()
                    .map(Module::getName)
                    .filter(n -> n.toLowerCase(Locale.ROOT).startsWith(modulePrefix.toLowerCase(Locale.ROOT)))
                    .sorted()
                    .distinct();
        }

        if ((action.equals("add")) && size == 3) {
            String keyPrefix = args.peekString(2);
            return KeyStorage.keyMap.keySet().stream()
                    .filter(k -> k.toLowerCase(Locale.ROOT).startsWith(keyPrefix.toLowerCase(Locale.ROOT)))
                    .sorted()
                    .distinct();
        }

        if ((action.equals("remove")) && size == 2) {
            String modulePrefix = args.peekString(1);
            return moduleStorage.getModules().stream()
                    .filter(m -> m.getKey() != -1)
                    .map(Module::getName)
                    .filter(n -> n.toLowerCase(Locale.ROOT).startsWith(modulePrefix.toLowerCase(Locale.ROOT)))
                    .sorted()
                    .distinct();
        }

        return Stream.empty();
    }

    @Override
    public String getShortDesc() {
        return "Manage binding module to key";
    }

    @Override
    public List<String> getLongDesc() {
        return Arrays.asList(
            "Command for settings and deletion binding module to key",
            "",
            "Usage:",
            "> bind add <module> <key> — bind module to key",
            "> bind remove <module> — unbind module from keys",
            "> bind list — show all bound modules",
            "> bind clear — unbind all modules from their keys"
        );
    }
}