package zov.tikiware.util.commands.api;

import zov.tikiware.util.commands.api.argparser.IArgParserManager;

public interface ICommandSystem {
    IArgParserManager getParserManager();
}
