package zov.tikiware.util.commands.api.exception;

public class CommandTooManyArgumentsException extends CommandErrorMessageException {

    public CommandTooManyArgumentsException(int maxArgs) {
        super(String.format(maxArgs == 1 ? "Too many arguments, maximum %d argument" : maxArgs > 4 ? "Too many arguments, maximum %d arguments" : "Too many arguments, maximum %d argument", maxArgs));
    }
}
