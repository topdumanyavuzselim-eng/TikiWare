package zov.tikiware.util.commands.api.exception;

import zov.tikiware.util.QuickLogger;
import zov.tikiware.util.commands.api.ICommand;
import zov.tikiware.util.commands.api.argument.ICommandArgument;

import java.util.List;

public class CommandNotFoundException extends CommandException implements QuickLogger {

    public final String command;

    public CommandNotFoundException(String command) {
        super(String.format("Command not found: %s", command));
        this.command = command;
    }

    @Override
    public void handle(ICommand command, List<ICommandArgument> args) {
       logDirect(getMessage());
    }
}
