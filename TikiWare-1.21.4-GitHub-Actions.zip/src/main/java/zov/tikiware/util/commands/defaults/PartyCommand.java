package zov.tikiware.util.commands.defaults;

import com.google.gson.JsonObject;
import net.minecraft.util.Formatting;
import zov.tikiware.util.IMinecraft;
import zov.tikiware.util.chat.ChatUtil;
import zov.tikiware.util.commands.api.Command;
import zov.tikiware.util.commands.api.argument.IArgConsumer;
import zov.tikiware.util.commands.api.exception.CommandException;
import zov.tikiware.util.commands.api.exception.CommandNotEnoughArgumentsException;
import zov.tikiware.util.commands.api.helpers.TabCompleteHelper;
import zov.tikiware.util.party.connection.PartyApiClient;

import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

public class PartyCommand extends Command implements IMinecraft {

    public PartyCommand() {
        super("party");
    }

    @Override
    public void execute(String label, IArgConsumer args) throws CommandException {
        String action = args.hasAny()
                ? args.getString().toLowerCase(Locale.ROOT)
                : "help";

        switch (action) {
            case "create" -> handleCreate(args);
            case "invite" -> handleInvite(args);
            case "join" -> handleJoin(args);
            case "leave" -> handleLeave();
            case "disband" -> handleDisband();
            case "list" -> handleList();
            case "kick" -> handleKick(args);
            default -> logDirect("Unknown subcommand");
        }
    }

    private String nick() {
        return mc.player.getNameForScoreboard();
    }

    private void handleCreate(IArgConsumer args) throws CommandException {
        args.requireMin(1);
        String name = args.getString();

        JsonObject req = new JsonObject();
        req.addProperty("leader", nick());
        req.addProperty("name", name);

        PartyApiClient.postAsync("/party/create", req, json -> {
            ChatUtil.send(
                    Formatting.GRAY + "you created party with name " +
                            Formatting.WHITE + name
            );
        });
    }

    private void handleInvite(IArgConsumer args) throws CommandException {
        args.requireMin(1);
        String target = args.getString();

        JsonObject req = new JsonObject();
        req.addProperty("leader", nick());
        req.addProperty("target", target);

        PartyApiClient.postAsync("/party/invite", req, json ->
                ChatUtil.send(Formatting.GRAY + "you invited player " + Formatting.WHITE + target)
        );
    }

    private void handleJoin(IArgConsumer args) throws CommandException {
        args.requireMin(1);
        String party = args.getString();

        JsonObject req = new JsonObject();
        req.addProperty("player", nick());
        req.addProperty("party", party);

        PartyApiClient.postAsync("/party/join", req, json ->
                ChatUtil.send(Formatting.GRAY + "you joined in party " + Formatting.WHITE + party)
        );
    }

    private void handleLeave() {
        JsonObject req = new JsonObject();
        req.addProperty("player", nick());

        PartyApiClient.postAsync("/party/leave", req, json ->
                ChatUtil.send(Formatting.GRAY + "you left party")
        );
    }

    private void handleDisband() {
        JsonObject req = new JsonObject();
        req.addProperty("leader", nick());

        PartyApiClient.postAsync("/party/disband", req, json ->
                ChatUtil.send(Formatting.GRAY + "you disbanded party")
        );
    }

    private void handleKick(IArgConsumer args) throws CommandException {
        args.requireMin(1);
        String target = args.getString();

        JsonObject req = new JsonObject();
        req.addProperty("leader", nick());
        req.addProperty("target", target);

        PartyApiClient.postAsync("/party/kick", req, json ->
                ChatUtil.send(Formatting.GRAY + "you kicked player " + Formatting.WHITE + target)
        );
    }

    private void handleList() {
        JsonObject req = new JsonObject();
        req.addProperty("player", nick());

        PartyApiClient.postAsync("/party/list", req, json -> {
            String[] members = json.get("message").getAsString().split(", ");

            ChatUtil.send(Formatting.GRAY + "Players in party:");
            for (String m : members) {
                ChatUtil.send(" " + Formatting.WHITE + m);
            }
        });
    }

    @Override
    public Stream<String> tabComplete(String label, IArgConsumer args) throws CommandNotEnoughArgumentsException {
        int size = args.getArgs().size();

        if (size <= 1) {
            String prefix = size == 1 ? args.peekString(0) : "";
            return new TabCompleteHelper()
                    .prepend("create", "invite", "join", "leave", "disband", "list", "kick")
                    .filterPrefix(prefix)
                    .sortAlphabetically()
                    .stream();
        }

        return Stream.empty();
    }

    @Override
    public String getShortDesc() {
        return "Allows see players from party on any distance";
    }

    @Override
    public List<String> getLongDesc() {
        return List.of(
                "Command for management party system",
                "",
                "Usage:",
                "> party create <name> - Create party",
                "> party invite <player> - Invite player (leader)",
                "> party join <name> - Join in party",
                "> party leave - Leave from party",
                "> party disband - Disband party (leader)",
                "> party list - view list players in party",
                "> party kick <player> - Kick player (leader)"
        );
    }
}