package zov.tikiware.util.packet;

import lombok.Getter;
import lombok.experimental.UtilityClass;
import net.minecraft.network.packet.Packet;
import zov.tikiware.util.IMinecraft;

import java.util.ArrayList;
import java.util.List;

@UtilityClass
public class NetworkUtils implements IMinecraft {

    @Getter
    private final List<Packet<?>> silentPackets = new ArrayList<>();

    public void sendSilentPacket(Packet<?> packet) {
        silentPackets.add(packet);
        NetworkUtils.sendPacket(packet);
    }

    public void sendPacket(Packet<?> packet) {
        mc.getNetworkHandler().sendPacket(packet);
    }
}