package zov.tikiware.util.staff;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class Staff {
    public String name;
}