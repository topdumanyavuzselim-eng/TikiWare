package zov.tikiware.module;

public enum ModuleCategory {
    COMBAT,
    MOVEMENT,
    RENDER,
    PLAYER,
    MISC
}