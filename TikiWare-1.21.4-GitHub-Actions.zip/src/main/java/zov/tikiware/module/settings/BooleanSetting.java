package zov.tikiware.module.settings;

import lombok.Getter;
import lombok.Setter;
import zov.tikiware.util.render.math.Animation;
import zov.tikiware.util.render.math.Easing;

import java.util.function.Supplier;

@Getter
@Setter
public class BooleanSetting extends Setting {
    private final Animation animation = new Animation(Easing.QUINTIC_OUT, 400);
    private final Animation clickAnimation = new Animation(Easing.QUINTIC_OUT, 400);
    private boolean clicked;
    private boolean value;
    private int key = -1;

    public BooleanSetting(String name, boolean defaultValue) {
        super(name);
        this.value = defaultValue;
    }

    public boolean getValue() {
        return value;
    }

    @Override
    public String getValueAsString() {
        return Boolean.toString(value);
    }

    @Override
    public void setValueFromString(String value) {
        this.value = Boolean.parseBoolean(value);
    }

    public void toggle() {
        this.value = !this.value;
    }

    @Override
    public BooleanSetting setVisible(Supplier<Boolean> visible) {
        this.visible = visible;
        return this;
    }
}