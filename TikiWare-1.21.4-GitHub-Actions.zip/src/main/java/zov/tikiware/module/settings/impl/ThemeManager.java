package zov.tikiware.module.settings.impl;

public class ThemeManager {
    private static ThemeManager instance;

    // Creating default theme by default (Name, Color 1, Color 2 in HEX format ARGB)
    // 0xFF4A90E2 - this blue color, 0xFF9013FE - purple.
    // you can change these HEX-codes on any other own favorite colors!
    private final Theme defaultTheme = new Theme("Default", 0xFF4A90E2, 0xFF9013FE);

    private ThemeManager() {
    }

    public static ThemeManager getInstance() {
        if (instance == null) {
            instance = new ThemeManager();
        }
        return instance;
    }

    public Theme getCurrentTheme() {
        return defaultTheme; // just always return this default theme
    }

}