package zov.tikiware.module;

import com.google.common.eventbus.Subscribe;
import com.google.gson.JsonObject;
import lombok.Getter;
import lombok.Setter;
import net.minecraft.client.option.Perspective;
import net.minecraft.util.math.MathHelper;
import zov.tikiware.TikiWare;
import zov.tikiware.event.EventGameUpdate;
import zov.tikiware.event.list.EventHUD;
import zov.tikiware.event.list.EventKeyInput;
import zov.tikiware.event.list.EventTick;
import zov.tikiware.module.list.combat.*;
import zov.tikiware.module.list.misc.*;
import zov.tikiware.module.list.movement.*;
import zov.tikiware.module.list.player.*;
import zov.tikiware.module.list.render.*;
import zov.tikiware.module.list.render.hud.Interface;
import zov.tikiware.module.settings.BooleanSetting;
import zov.tikiware.module.settings.ThemeSetting;
import zov.tikiware.util.IMinecraft;
import zov.tikiware.util.base.Instance;
import zov.tikiware.util.party.connection.PartyApiClient;
import zov.tikiware.util.player.other.SlownessManager;
import zov.tikiware.util.rotation.Rotation;
import zov.tikiware.util.rotation.RotationComponent;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Getter
public class ModuleStorage implements IMinecraft {
    private final List<Module> modules = new ArrayList<>();

    public void injectRegisterModules() {
        modules.addAll(List.of(
                new FullBright(), new ClickGui(), new Sprint(),
                 new TriggerBot(),
                new NoRender(), new KillAura(),
                new Tags(), new TargetESP(), new NoPush(), new SoulESP(),
                new NoJumpDelay(), new TeleportBack(), new ElytraHelper(),
                new AutoTotem(), new ClickPearl(), new UseTracker(), new CrystalAura(),
                new ClientSounds(), new NoFriendDamage(), new ElytraBooster(),
                new FreeCamera(), new SwingAnimations(), new Predictions(),
                new DogFly(), new AutoTpaccept(), new RPSpoofer(), new FireFly(),
                new AntiBot(), new AutoExplosion(), new DeathCoords(), new CrystalOptimizer(),
                new GuiMove(), new Tracers(), new ElytraMotion(), new Velocity(), new ElytraFlight(),
                new ViewModel(), new KillEffect(), new AutoArmor(), new LonyHelper(),new Speed(),
                new AutoTool(), new TapeMouse(), new Ambience(), new BlockOverlay(), new FreeLook(), new Chams(),
                new Trails(), new FastExp(), new NameProtect(), new CrystalSpammer(), new ChinaHat(),
                new AirStuck(), new AutoSwap(), new NoSlow(), new NoWeb(), new FakePlayer(), new Interface(), new AutoEat(),new AutoLeave(), new WellJoiner(), new WellSaver(),
                new Wings(), new ScoreboardHealth(), new AutoPotion(), new GrimGlide()
        ));

        TikiWare.getInstance().getEventBus().register(this);
    }

    public <T extends Module> T get(final String name) {
        return this.modules.stream()
                .filter(module -> module.getName().equalsIgnoreCase(name))
                .map(module -> (T) module)
                .findFirst()
                .orElse(null);
    }

    public <T extends Module> T get(final Class<T> clazz) {
        return this.modules.stream()
                .filter(module -> clazz.isAssignableFrom(module.getClass()))
                .map(clazz::cast)
                .findFirst()
                .orElse(null);
    }

    public List<Module> get(final ModuleCategory category) {
        return this.modules.stream()
                .filter(module -> module.getCategory() == category)
                .collect(Collectors.toList());
    }

    @Setter private float speedAcceleration;
    @Setter private float randomness;

    @Subscribe
    private void onGameUpdate(EventGameUpdate e) {
        if (mc.player == null) return;

        if (!SlownessManager.slowTasksIsEmpty()) SlownessManager.updateSlowTasks();
        if (!SlownessManager.timeTasksIsEmpty()) SlownessManager.updateTimeTasks(false);

        var aura = get(KillAura.class);

        if (!aura.isEnabled() || aura.getTarget() == null) {
            if (mc.options.getPerspective() == Perspective.THIRD_PERSON_FRONT) {
                aura.lastYaw = (mc.gameRenderer.getCamera().getYaw() - 180);
                aura.lastPitch = -mc.gameRenderer.getCamera().getPitch();
            } else {
                aura.lastYaw = mc.gameRenderer.getCamera().getYaw();
                aura.lastPitch = mc.gameRenderer.getCamera().getPitch();
            }

            if (aura.rotation.is("Vanilla") || Instance.get(FreeLook.class).isActive()) return;

            updateBackwardsOther();
        }
    }

    @Subscribe
    private void onRender(EventHUD ignored) {
        for (var module : getModules()) {
            module.getAnimation().run(module.isEnabled());
            for (var setting : module.getSettings()) {
                if (setting instanceof BooleanSetting b) b.getAnimation().run(b.getValue());
                if (setting instanceof ThemeSetting t) t.getValue().animation.run(1);
            }
        }
    }

    @Subscribe
    private void onKey(EventKeyInput e) {
        if (e.getAction() == 0) return;
        for (var module : getModules())
            module.getSettings().stream().filter(setting -> setting instanceof BooleanSetting b && e.getKey() == b.getKey()).forEach(setting -> ((BooleanSetting) setting).toggle());
    }

    @Subscribe
    private void onUpdate(EventTick ignored) {
        if (!SlownessManager.timeTasksIsEmpty()) SlownessManager.updateTimeTasks(true);

        if (mc.player == null || true) return;

        PartyApiClient.fetchPartyStateAsync();
        PartyApiClient.fetchInvitesAsync();

        JsonObject j = new JsonObject();
        j.addProperty("player", mc.player.getNameForScoreboard());
        j.addProperty("x", mc.player.getX());
        j.addProperty("y", mc.player.getY());
        j.addProperty("z", mc.player.getZ());

        PartyApiClient.postAsync("/party/pos", j, json -> {});
    }

    private void updateBackwardsOther() {
        if(mc.player.isGliding()){
            speedAcceleration += 0.06f;

        }
        else{
            speedAcceleration += 0.006f;

        }
        get(KillAura.class).speedAcceleration = 0;

        var angle = new Rotation(mc.gameRenderer.getCamera().getYaw(), mc.gameRenderer.getCamera().getPitch());

        var deltaYaw = MathHelper.wrapDegrees(angle.getYaw() - mc.player.getYaw());
        var deltaPitch = angle.getPitch() - mc.player.getPitch();
        if (mc.options.getPerspective() == Perspective.THIRD_PERSON_FRONT) {
            deltaYaw = MathHelper.wrapDegrees((angle.getYaw() - 180) - mc.player.getYaw());
            deltaPitch = MathHelper.wrapDegrees(-angle.getPitch() - mc.player.getPitch());
        }

        var smooth = Math.max(speedAcceleration, 0);

        var newYaw = mc.player.getYaw() + deltaYaw * (Math.min(Math.max(smooth, 0), 1));
        var newPitch = mc.player.getPitch() + deltaPitch * (Math.min(Math.max(smooth / 2, 0), 1));

        var smoothRot = new Rotation(newYaw, newPitch);

        RotationComponent.update(smoothRot, 360, 360, 360, 360, 0, 2, false);
    }
}
