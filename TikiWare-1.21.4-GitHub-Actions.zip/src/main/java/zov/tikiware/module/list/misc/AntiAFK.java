package zov.tikiware.module.list.misc;

import com.google.common.eventbus.Subscribe;
import net.minecraft.util.Hand;
import zov.tikiware.event.list.EventPlayerUpdate;
import zov.tikiware.module.Module;
import zov.tikiware.module.ModuleCategory;
import zov.tikiware.module.ModuleInformation;
import zov.tikiware.util.math.StopWatch;

@ModuleInformation(moduleName = "Anti AFK", moduleDesc = "Prevents kick for AFK", moduleCategory = ModuleCategory.MISC)
public class AntiAFK extends Module {

    private final StopWatch stopWatch = new StopWatch();

    @Subscribe
    private void onUpdate(EventPlayerUpdate e) {
        if (mc.player == null || mc.world == null) return;

        if (stopWatch.isReached(10000)) {
            mc.player.swingHand(Hand.MAIN_HAND);
            mc.player.jump();
            stopWatch.reset();
        }
    }

    @Override
    public void onEnable() {
        super.onEnable();
        stopWatch.reset();
    }
}
