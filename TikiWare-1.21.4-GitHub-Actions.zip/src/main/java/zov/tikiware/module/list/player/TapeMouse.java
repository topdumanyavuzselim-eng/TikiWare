package zov.tikiware.module.list.player;

import com.google.common.eventbus.Subscribe;
import zov.tikiware.event.list.EventTick;
import zov.tikiware.module.Module;
import zov.tikiware.module.ModuleCategory;
import zov.tikiware.module.ModuleInformation;
import zov.tikiware.module.settings.BooleanSetting;
import zov.tikiware.module.settings.SliderSetting;
import zov.tikiware.util.bot.BotSessionManager;

@ModuleInformation(moduleName = "Tape Mouse", moduleDesc = "Automatic clicks for background bots", moduleCategory = ModuleCategory.PLAYER)
public class TapeMouse extends Module {
    private final SliderSetting cps = new SliderSetting("CPS", 1, 0, 2, 0.05f);
    private final BooleanSetting rightClick = new BooleanSetting("Right button", false);
    private final BooleanSetting onlyBots = new BooleanSetting("Only bots", true);

    private long lastClick;

    @Subscribe
    private void onTick(EventTick eventTick) {
        long delay = (long) (1000.0f / cps.getValue());
        long now = System.currentTimeMillis();

        if (now - lastClick < delay) {
            return;
        }

        if (!onlyBots.getValue()) {
            clickForLocalPlayer();
        }

        if (!BotSessionManager.getConnections().isEmpty()) {
            BotSessionManager.pulseBots(rightClick.getValue());
        }

        lastClick = now;
    }

    private void clickForLocalPlayer() {
        if (mc.player == null || mc.currentScreen != null) return;

        if (rightClick.getValue()) {
            mc.doItemUse();
        } else {
            mc.doAttack();
        }
    }
}