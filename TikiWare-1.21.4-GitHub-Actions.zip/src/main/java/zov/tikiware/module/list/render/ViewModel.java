package zov.tikiware.module.list.render;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import net.minecraft.util.math.RotationAxis;
import zov.tikiware.module.Module;
import zov.tikiware.module.ModuleCategory;
import zov.tikiware.module.ModuleInformation;
import zov.tikiware.module.settings.SliderSetting;

/**
 * First-person held-item positioning and visual tuning.
 * Kept as ViewModel internally for compatibility with the existing mixin,
 * while exposed to the user as the more descriptive "Hold My Items" module.
 */
@ModuleInformation(moduleName = "Hold My Items", moduleDesc = "Customizes first-person held-item position, scale and rotation", moduleCategory = ModuleCategory.RENDER)
public class ViewModel extends Module {
    private final SliderSetting offsetLeftX = new SliderSetting("Left Hand X", 0.0F, -2F, 2F, 0.05F);
    private final SliderSetting offsetLeftY = new SliderSetting("Left Hand Y", 0.0F, -2F, 2F, 0.05F);
    private final SliderSetting offsetLeftZ = new SliderSetting("Left Hand Z", 0.0F, -2F, 2F, 0.05F);
    private final SliderSetting offsetRightX = new SliderSetting("Right Hand X", 0.0F, -2F, 2F, 0.05F);
    private final SliderSetting offsetRightY = new SliderSetting("Right Hand Y", 0.0F, -2F, 2F, 0.05F);
    private final SliderSetting offsetRightZ = new SliderSetting("Right Hand Z", 0.0F, -2F, 2F, 0.05F);

    private final SliderSetting scale = new SliderSetting("Scale", 1.0F, 0.5F, 1.5F, 0.01F);
    private final SliderSetting rotationX = new SliderSetting("Rotation X", 0.0F, -180F, 180F, 1F);
    private final SliderSetting rotationY = new SliderSetting("Rotation Y", 0.0F, -180F, 180F, 1F);
    private final SliderSetting rotationZ = new SliderSetting("Rotation Z", 0.0F, -180F, 180F, 1F);

    public void applyHandPosition(MatrixStack matrices, Arm arm) {
        if (!this.isEnabled()) return;

        if (arm == Arm.LEFT) {
            matrices.translate(offsetLeftX.getValue(), offsetLeftY.getValue(), offsetLeftZ.getValue());
        } else {
            matrices.translate(offsetRightX.getValue(), offsetRightY.getValue(), offsetRightZ.getValue());
        }

        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(rotationX.getFloatValue()));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(rotationY.getFloatValue()));
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(rotationZ.getFloatValue()));

        float s = scale.getFloatValue();
        matrices.scale(s, s, s);
    }
}
