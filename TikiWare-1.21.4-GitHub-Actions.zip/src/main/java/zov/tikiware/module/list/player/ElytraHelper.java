package zov.tikiware.module.list.player;

import com.google.common.eventbus.Subscribe;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Formatting;
import zov.tikiware.event.list.EventKeyInput;
import zov.tikiware.event.list.EventPlayerUpdate;
import zov.tikiware.event.list.EventTick;
import zov.tikiware.module.Module;
import zov.tikiware.module.ModuleCategory;
import zov.tikiware.module.ModuleInformation;
import zov.tikiware.module.settings.BindSetting;
import zov.tikiware.module.settings.BooleanSetting;
import zov.tikiware.module.settings.ModeSetting;
import zov.tikiware.util.chat.ChatUtil;
import zov.tikiware.util.packet.NetworkUtils;
import zov.tikiware.util.player.other.InventoryUtil;

@ModuleInformation(moduleName = "Elytra Helper", moduleCategory = ModuleCategory.PLAYER)
public class ElytraHelper extends Module {
    private final ModeSetting mode = new ModeSetting("Mode", "Vanilla", "Vanilla", "Grim", "Polar");
    private final BindSetting swapKey = new BindSetting("Button swap", -1);
    private final BindSetting fireworkKey = new BindSetting("Button firework", -1);
    private final ModeSetting throwFireworkMode = new ModeSetting("Mode launch firework", "Normal", "Normal", "Legit");
    private final BooleanSetting autoTakeoff = new BooleanSetting("Auto Takeoff", true);

    private boolean fireworkUsed;
    private boolean swapped;

    @Subscribe
    private void onKey(EventKeyInput e) {
        if (e.getAction() == 0) return;
        if (e.getKey() == swapKey.getValue()) swapped = true;
        if (e.getKey() == fireworkKey.getValue() && mc.player.isGliding()) fireworkUsed = true;
    }

    @Subscribe
    private void onPlayerUpdate(EventPlayerUpdate e) {
        if (!swapped) return;
        swapped = false;
        swap(mode, mc.player.getEquippedStack(EquipmentSlot.CHEST).getItem() == Items.ELYTRA);
    }

    @Subscribe
    private void onTick(EventTick e) {
        if (mc.player == null) return;

        if (autoTakeoff.getValue()) {
            var chest = mc.player.getEquippedStack(EquipmentSlot.CHEST);

            if (chest.getItem() == Items.ELYTRA
                    && !mc.player.isInLava()
                    && !mc.player.isTouchingWater()
                    && mc.player.isOnGround()
                    && !mc.player.hasVehicle()
                    && !mc.player.isGliding()
                    && !mc.player.isSpectator()
                    && !mc.options.jumpKey.isPressed()) {
                mc.player.jump();
            }

            if (chest.getItem() == Items.ELYTRA
                    && !mc.player.isInLava()
                    && !mc.player.isTouchingWater()
                    && !mc.player.isOnGround()
                    && !mc.player.hasVehicle()
                    && !mc.player.isGliding()
                    && !mc.player.isSpectator()) {
                NetworkUtils.sendSilentPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
                mc.player.startGliding();
            }
        }

        if (!fireworkUsed) return;
        switch (throwFireworkMode.getValue()) {
            case "Normal" -> InventoryUtil.swapAndUseHvH(Items.FIREWORK_ROCKET);
            case "Legit" -> InventoryUtil.swapAndUseLegit(Items.FIREWORK_ROCKET);
        }
        fireworkUsed = false;
    }

    public void swap(ModeSetting mode, boolean chestplate) {
        switch (mode.getValue()) {
            case "Vanilla" -> vanillaSwap(chestplate);
            case "Grim" -> grimSwap(chestplate);
            case "Polar" -> polarSwap(chestplate);
        }
    }

    private void vanillaSwap(boolean chestplate) {
        var slot = chestplate ? InventoryUtil.findBestChestplateSlot() : InventoryUtil.findBestElytraSlot();

        if (slot == -1) {
            var info = "Elytra" + Formatting.GRAY + " not found in inventory";
            if (chestplate) info = "Chestplate" + Formatting.GRAY + " not found in inventory";
            ChatUtil.send(info);
            return;
        }

        if (slot >= 0 && slot <= 8) mc.interactionManager.clickSlot(0, 6, slot, SlotActionType.SWAP, mc.player);
        else if (slot >= 8 && slot <= 45) {
            mc.interactionManager.clickSlot(0, slot, 8, SlotActionType.SWAP, mc.player);
            mc.interactionManager.clickSlot(0, 6, 8, SlotActionType.SWAP, mc.player);
            mc.interactionManager.clickSlot(0, slot, 8, SlotActionType.SWAP, mc.player);
        }
    }

    private void grimSwap(boolean chestplate) {
        var slot = chestplate ? InventoryUtil.findBestChestplateSlot() : InventoryUtil.findBestElytraSlot();

        if (slot == -1) {
            var info = "Elytra" + Formatting.GRAY + " not found in inventory";
            if (chestplate) info = "Chestplate" + Formatting.GRAY + " not found in inventory";
            ChatUtil.send(info);
            return;
        }

        if (slot >= 0 && slot <= 8) {
            InventoryUtil.swapWithBypassGrim(() -> mc.interactionManager.clickSlot(0, 6, slot, SlotActionType.SWAP, mc.player));
        } else if (slot >= 8 && slot <= 45) {
            InventoryUtil.swapWithBypassGrim(() -> {
                mc.interactionManager.clickSlot(0, slot, 8, SlotActionType.SWAP, mc.player);
                mc.interactionManager.clickSlot(0, 6, 8, SlotActionType.SWAP, mc.player);
                mc.interactionManager.clickSlot(0, slot, 8, SlotActionType.SWAP, mc.player);
            });
        }
    }

    private void polarSwap(boolean chestplate) {
        var slot = chestplate ? InventoryUtil.findBestChestplateSlot() : InventoryUtil.findBestElytraSlot();

        if (slot == -1) {
            var info = "Elytra" + Formatting.GRAY + " not found in inventory";
            if (chestplate) info = "Chestplate" + Formatting.GRAY + " not found in inventory";
            ChatUtil.send(info);
            return;
        }

        if (slot >= 0 && slot <= 8) {
            InventoryUtil.swapWithBypassPolar(() -> {
                mc.interactionManager.clickSlot(0, 6, slot, SlotActionType.SWAP, mc.player);
            });
        } else if (slot >= 8 && slot <= 45) {
            InventoryUtil.swapWithBypassPolar(() -> {
                mc.interactionManager.clickSlot(0, slot, 8, SlotActionType.SWAP, mc.player);
                mc.interactionManager.clickSlot(0, 6, 8, SlotActionType.SWAP, mc.player);
                mc.interactionManager.clickSlot(0, slot, 8, SlotActionType.SWAP, mc.player);
            });
        }
    }
}