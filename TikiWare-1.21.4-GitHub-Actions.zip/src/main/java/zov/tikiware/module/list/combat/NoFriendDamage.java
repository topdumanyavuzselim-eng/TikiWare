package zov.tikiware.module.list.combat;

import com.google.common.eventbus.Subscribe;
import zov.tikiware.event.list.EventAttack;
import zov.tikiware.module.Module;
import zov.tikiware.module.ModuleCategory;
import zov.tikiware.module.ModuleInformation;
import zov.tikiware.util.friend.Friend;
import zov.tikiware.util.friend.FriendRepository;

@ModuleInformation(moduleName = "No Friend Damage", moduleCategory = ModuleCategory.COMBAT)
public class NoFriendDamage extends Module {

    @Subscribe
    private void onAttack(EventAttack e) {
        for (Friend friend : FriendRepository.getFriends()) {
            if (e.getEntity() == mc.player) continue;
            if (!e.getEntity().getNameForScoreboard().equals(friend.name())) continue;
            e.cancelEvent();
        }
    }
}