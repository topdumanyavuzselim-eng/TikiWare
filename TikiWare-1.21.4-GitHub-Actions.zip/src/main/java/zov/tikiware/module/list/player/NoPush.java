package zov.tikiware.module.list.player;

import zov.tikiware.module.Module;
import zov.tikiware.module.ModuleCategory;
import zov.tikiware.module.ModuleInformation;
import zov.tikiware.module.settings.BooleanSetting;
import zov.tikiware.module.settings.ModeListSetting;

@ModuleInformation(moduleName = "No Push", moduleCategory = ModuleCategory.PLAYER)
public class NoPush extends Module {
    public final ModeListSetting objects = new ModeListSetting("Objects",
            new BooleanSetting("Players", true),
            new BooleanSetting("Blocks", true)
    );
}