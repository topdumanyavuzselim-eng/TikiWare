package zov.tikiware.module.list.movement;

import com.google.common.eventbus.Subscribe;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.Vec3d;
import zov.tikiware.event.list.EventPacket;
import zov.tikiware.event.list.EventTick;
import zov.tikiware.module.Module;
import zov.tikiware.module.ModuleCategory;
import zov.tikiware.module.ModuleInformation;
import zov.tikiware.module.list.player.ElytraHelper;
import zov.tikiware.module.settings.BooleanSetting;
import zov.tikiware.module.settings.ModeSetting;
import zov.tikiware.util.base.Instance;
import zov.tikiware.util.chat.ChatUtil;

@ModuleInformation(moduleName = "Air Stuck", moduleCategory = ModuleCategory.MOVEMENT)
public class AirStuck extends Module {

    private final ModeSetting mode = new ModeSetting("Mode", "Vanilla", "Vanilla", "Grim", "Polar");

    private final BooleanSetting autoSwapChest = new BooleanSetting("swap on chestplate", true);
    private final BooleanSetting backElytra = new BooleanSetting("Restore when disable", true)
            .setVisible(autoSwapChest::getValue);
    private final BooleanSetting fallCheck = new BooleanSetting("Check on fall", true);

    private Vec3d savedVelocity = Vec3d.ZERO;
    private boolean isElytra;

    @Subscribe
    private void onPacket(EventPacket e) {
        if (mc.player == null) return;

        if (e.getPacket() instanceof PlayerMoveC2SPacket) e.cancelEvent();
    }

    @Subscribe
    private void onTick(EventTick e) {
        if (mc.player == null) return;

        mc.player.setVelocity(0, 0, 0);
        mc.player.setNoGravity(true);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (mc.player == null || mc.world == null) return;

        if (mc.player.fallDistance == 0 && fallCheck.getValue()) {
            ChatUtil.send("you need fall");
            setEnabled(false);
            return;
        }

        mc.player.setNoGravity(true);

        savedVelocity = mc.player.getVelocity();

        boolean wearingElytra = mc.player.getEquippedStack(EquipmentSlot.CHEST).getItem() == Items.ELYTRA;

        if (!wearingElytra || !autoSwapChest.getValue()) return;
        isElytra = true;

        Instance.get(ElytraHelper.class).swap(mode, true);
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (mc.player == null) return;

        if (mc.player.fallDistance == 0 && fallCheck.getValue()) return;

        if (savedVelocity != null) mc.player.setVelocity(savedVelocity);

        mc.player.setNoGravity(false);

        boolean wearingChestPlate = mc.player.getEquippedStack(EquipmentSlot.CHEST).getItem() instanceof ArmorItem;

        if (!wearingChestPlate || !(autoSwapChest.getValue() && backElytra.getValue()) || !isElytra) return;
        isElytra = false;

        Instance.get(ElytraHelper.class).swap(mode, false);
    }
}