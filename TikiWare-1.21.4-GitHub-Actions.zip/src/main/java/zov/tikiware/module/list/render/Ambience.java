package zov.tikiware.module.list.render;

import zov.tikiware.module.Module;
import zov.tikiware.module.ModuleCategory;
import zov.tikiware.module.ModuleInformation;
import zov.tikiware.module.settings.BooleanSetting;
import zov.tikiware.module.settings.ModeSetting;
import zov.tikiware.module.settings.SliderSetting;

@ModuleInformation(moduleName = "Ambience", moduleDesc = "Custom time and fog", moduleCategory = ModuleCategory.RENDER)
public class Ambience extends Module {

    public final ModeSetting timePreset = new ModeSetting("time", "Day",
            "Day", "Dawn", "Sunset", "Dusk", "Night", "Midnight");

    public final BooleanSetting customFog = new BooleanSetting("fog", false);
    public final SliderSetting fogDistance = new SliderSetting("range fog", 100, 10, 500, 10).setVisible(() -> customFog.getValue());
    public final BooleanSetting themeFogColor = new BooleanSetting("Color fog from theme", false).setVisible(() -> customFog.getValue());

    public long getCustomTime() {
        return switch (timePreset.getValue()) {
            case "Dawn" -> 23000;
            case "Day" -> 6000;
            case "Sunset" -> 12500;
            case "Dusk" -> 13500;
            case "Night" -> 16000;
            case "Midnight" -> 18000;
            default -> 6000;
        };
    }

    public boolean isFogEnabled() {
        return customFog.getValue();
    }

    public float getFogDistance() {
        return (float) fogDistance.getValue();
    }

    public boolean isThemeFogColorEnabled() {
        return themeFogColor.getValue();
    }
}
