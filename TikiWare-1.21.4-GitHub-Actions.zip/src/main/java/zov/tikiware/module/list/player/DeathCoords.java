package zov.tikiware.module.list.player;

import com.google.common.eventbus.Subscribe;
import zov.tikiware.event.list.EventTick;
import zov.tikiware.module.Module;
import zov.tikiware.module.ModuleCategory;
import zov.tikiware.module.ModuleInformation;

@ModuleInformation(moduleName = "Death Coords", moduleCategory = ModuleCategory.PLAYER)
public class DeathCoords extends Module {

    private boolean send;

    @Subscribe
    private void onUpdate(EventTick e) {
        if (mc.player == null) return;
        if (mc.player.isDead()) {
            if (!send) {
                logDirect(String.format("you died on XYZ: %.0f %.0f %.0f", mc.player.getX(), mc.player.getY(), mc.player.getZ()).replace(",","."));
                send = true;
            }
        } else send = false;
    }
}