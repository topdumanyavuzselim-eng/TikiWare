package zov.tikiware.module.list.render;

import com.google.common.eventbus.Subscribe;
import zov.tikiware.event.list.EventTick;
import zov.tikiware.module.Module;
import zov.tikiware.module.ModuleCategory;
import zov.tikiware.module.ModuleInformation;
import zov.tikiware.module.settings.BooleanSetting;
import zov.tikiware.module.settings.ModeListSetting;

@ModuleInformation(moduleName = "Removals", moduleCategory = ModuleCategory.RENDER)
public class NoRender extends Module {

    public final ModeListSetting elements = new ModeListSetting("Remove elements",
            new BooleanSetting("Fire",true),
            new BooleanSetting("Blur in water",true),
            new BooleanSetting("Vision in blocks",true),
            new BooleanSetting("Camera Clip",true),
            new BooleanSetting("Shake camera",true)
    );

    @Subscribe
    public void onUpdate(EventTick e) {
        if (elements.isEnabled("Shake camera")) {
            mc.options.getDamageTiltStrength().setValue(0.0);
        } else {
            mc.options.getDamageTiltStrength().setValue(0.5);
        }
    }

    @Override
    public void onDisable() {
        mc.options.getDamageTiltStrength().setValue(0.5);
        super.onDisable();
    }
}