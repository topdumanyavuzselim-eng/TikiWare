package zov.tikiware.module.list.misc;

import zov.tikiware.module.Module;
import zov.tikiware.module.ModuleCategory;
import zov.tikiware.module.ModuleInformation;

@ModuleInformation(moduleName = "Scoreboard Health", moduleDesc = "Takes HP players from scoreboard", moduleCategory = ModuleCategory.MISC)
public class ScoreboardHealth extends Module {}