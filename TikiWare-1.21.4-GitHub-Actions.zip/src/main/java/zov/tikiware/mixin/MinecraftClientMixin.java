package zov.tikiware.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.RunArgs;
import net.minecraft.util.Util;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import zov.tikiware.event.EventGameUpdate;
import zov.tikiware.event.list.EventMinecraftInit;
import zov.tikiware.event.list.EventTick;
import zov.tikiware.event.list.EventTickEnd;
import zov.tikiware.module.list.combat.AutoExplosion;
import zov.tikiware.util.base.Instance;

@Mixin(MinecraftClient.class)
public class MinecraftClientMixin {
    @Unique
    private long lastHookTime = Util.getMeasuringTimeNano();
    @Unique
    private int accumulatedCalls = 0;

    @Inject(method = "getWindowTitle", at = @At(value = "HEAD"), cancellable = true)
    private void getWindowTitle(CallbackInfoReturnable<String> cir) {
        cir.setReturnValue("tikiware 1.21.4 (dev)");
    }

    @Inject(method = "<init>", at = @At(value = "NEW", target = "(Lnet/minecraft/client/MinecraftClient;Ljava/io/File;)Lnet/minecraft/client/option/GameOptions;"))
    private void initOptions(RunArgs args, CallbackInfo ci) {
        new EventMinecraftInit().post();
    }

    @Inject(method = "tick", at = @At(value = "HEAD"))
    private void tick(CallbackInfo ci) {
        new EventTick().post();
    }

    @Inject(method = "tick", at = @At(value = "RETURN"))
    private void tickEnd(CallbackInfo ci) {
        new EventTickEnd().post();
    }

    @Inject(method = "doItemUse", at = @At(value = "HEAD"), cancellable = true)
    private void fixAutoExplosion(CallbackInfo ci) {
        if (Instance.get(AutoExplosion.class).getTicksToDisableRightClicks() > 0) ci.cancel();
    }

    @Inject(method = "render", at = @At(value = "HEAD"))
    private void render(boolean tick, CallbackInfo ci) {
        var timeNano = Util.getMeasuringTimeNano();
        var deltaTime = timeNano - lastHookTime;
        accumulatedCalls += (int) (deltaTime / 4_166_666L);
        lastHookTime += (long) accumulatedCalls * 4_166_666L;

        for (accumulatedCalls = Math.min(accumulatedCalls, 240); accumulatedCalls > 0; --accumulatedCalls) new EventGameUpdate().post();
    }
}